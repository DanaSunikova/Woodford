// JavaScript source code
function selectRealEstate() {

	var lookupForm = new MobileCRM.UI.LookupForm();
	lookupForm.allowedViews = null; // Allow all views
	lookupForm.allowNull = true; // Allow choosing empty value
	lookupForm.entities = ["new_realestate"]; // Allow only accounts
	lookupForm.show(onRealEstateSelected, MobileCRM.bridge.alert, null);
}

function onRealEstateSelected(accountRef) {

	MobileCRM.DynamicEntity.loadById(
			"new_realestate",
			accountRef.id,
			setValuesFromRealEstate,
			MobileCRM.bridge.alert,
			null
		);

}

function setValuesFromRealEstate(realEstate) {

	var realEstateField = document.getElementById("realEstateField");
	realEstateField.value = realEstate.properties.new_name;
	var homeValue = document.getElementById("homeValue");
	homeValue.value = realEstate.properties.new_listprice;
	var loanAmount = document.getElementById("loanAmount");
	loanAmount.value = homeValue.value;

}

function selectContact() {

	var lookupForm = new MobileCRM.UI.LookupForm();
	lookupForm.allowedViews = null; // Allow all views
	lookupForm.allowNull = true; // Allow choosing empty value
	lookupForm.entities = ["contact"]; // Allow only accounts
	lookupForm.show(onContactSelected, MobileCRM.bridge.alert, null);

}

function onContactSelected(contactRef) {

	MobileCRM.DynamicEntity.loadById(
			"contact",
			contactRef.id,
			setValuesFromContact,
			MobileCRM.bridge.alert,
			null
		);

}

function setValuesFromContact(contactEntity) {

	var contact = document.getElementById("contact");
	contact.value = contactEntity.properties.firstname + " " + contactEntity.properties.lastname;
	var loanAmount = document.getElementById("loanAmount");
	loanAmount.value = contactEntity.properties.creditlimit;

}

function checkValues(P, term, ir) {
	output = "";
	if ((P.value == "") || isNaN(P.value)) {
		output += "LOAN AMOUNT is not a number! \n";
		P.value = "";
	}

	if ((term.value == "") || isNaN(term.value)) {
		output += "MORTGAGE TERM is not a number! \n";
		term.value = "";
	}

	if ((ir.value == "") || isNaN(ir.value)) {
		output += "INTEREST RATE is not a number! \n";
		ir.value = "";
	}

	if (output.length > 0) {
		alert(output);
		return false;
	}
	return true;
}

function calculateMortgageMontlyPayments() {
	var P = document.getElementById("loanAmount");
	var term = document.getElementById("mortgageTerm");
	var ir = document.getElementById("interestRate");

	if (checkValues(P, term, ir)) {

		var M = 0;
		var iAnnual = ir.value / 100;
		var i = iAnnual / 12;
		var n = term.value * 12;

		M = P.value * ((i * Math.pow((1 + i), n)) / (Math.pow((1 + i), n) - 1));
		var result = document.getElementById("result");
		result.value = M.toFixed(2);
	}
}
